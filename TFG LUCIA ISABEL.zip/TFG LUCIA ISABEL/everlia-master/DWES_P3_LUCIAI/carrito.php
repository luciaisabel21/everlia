<?php
session_start();

include_once $_SERVER['DOCUMENT_ROOT'] . "/DWES_P3_LUCIAI/database/funcionesBD.php";

crearTablaCarrito();

$productos = [
    ["id" => 1, "imagen" => "./imagenes/BALI.jpeg", "descripcion" => "7 días en Bali(Indonesia)", "precio" => 700, "destino" => "BALI"],
    ["id" => 2, "imagen" => "./imagenes/ISLANDIA.jpg", "descripcion" => "9 días en Islandia", "precio" => 1200, "destino" => "ISLANDIA"],
    ["id" => 3, "imagen" => "./imagenes/REPUBLICADOMINICANA.jpg", "descripcion" => "5 días en República Dominicana", "precio" => 900, "destino" => "REPÚBLICA DOMINICANA"],
    ["id" => 4, "imagen" => "./imagenes/croacia.jpg", "descripcion" => "4 días en Croacia", "precio" => 400, "destino" => "CROACIA"],
    ["id" => 5, "imagen" => "./imagenes/egipto.jpg", "descripcion" => "Producto 5 - 10 días en Egipto", "precio" => 1800, "destino" => "EGIPTO"],
    ["id" => 6, "imagen" => "./imagenes/laponia.jpg", "descripcion" => "6 días en Laponia", "precio" => 1000, "destino" => "LAPONIA"],
    ["id" => 7, "imagen" => "./imagenes/maldivas.jpg", "descripcion" => "15 días en Maldivas", "precio" => 2500, "destino" => "MALDIVAS"],
    ["id" => 8, "imagen" => "./imagenes/tanzania.jpg", "descripcion" => "12 días en Tanzania", "precio" => 1900, "destino" => "TANZANIA"],
    ["id" => 9, "imagen" => "./imagenes/dubai.webp", "descripcion" => "5 días en Dubai", "precio" => 1010, "destino" => "DUBAI"],
    ["id" => 10, "imagen" => "./imagenes/decoracion.jpg", "nombre" => "Luces blancas", "descripcion" => "decora la zona que desees con luces blancas", "precio" => 50, "cantidad" => 1],
    ["id" => 11, "imagen" => "./imagenes/decoracionProducto1.jpeg", "nombre" => "Velas con flores", "descripcion" => "decora la mesa con velas y flores", "precio" => 30, "cantidad" => 1],
    ["id" => 12, "imagen" => "./imagenes/decoracionProducto2.jpg", "nombre" => "Accesorio para silla", "descripcion" => "decora las sillas con flores", "precio" => 20, "cantidad" => 1],
    ["id" => 13, "imagen" => "./imagenes/vestidoNovia.jpg", "nombre" => "Vestido palabra de honor", "descripcion" => "vestido encaje palabra de honor", "precio" => 2000, "cantidad" => 1],
    ["id" => 14, "imagen" => "./imagenes/vestidoNovia2.jpg", "nombre" => "Vestido encaje con estampado de flores ", "descripcion" => "vestido escote en V ", "precio" => 2850, "cantidad" => 1],
    ["id" => 15, "imagen" => "./imagenes/vestidoNovia3.jpg", "nombre" => "Vestido blanco sencillo", "descripcion" => "vestido escote en V sencillo", "precio" => 1100, "cantidad" => 1],
    ["id" => 16, "imagen" => "./imagenes/TrajeHombre1.jpeg", "nombre" => "Traje azul", "descripcion" => "Traje azul con camisa y corbata color claro", "precio" => 380, "cantidad" => 1],
    ["id" => 17, "imagen" => "./imagenes/TrajeHombre2.jpeg", "nombre" => "Traje negro", "descripcion" => "Traje negro con camisa y corbata blancas", "precio" => 700, "cantidad" => 1],
    ["id" => 18, "imagen" => "./imagenes/TrajeHombre3.jpeg", "nombre" => "Traje negro", "descripcion" => "Traje negro con camisa blanca y corbata negra", "precio" => 650, "cantidad" => 1],
    ["id" => 19, "imagen" => "./imagenes/ramoFlores.jpg", "nombre" => "Ramo colores pastel", "descripcion" => "Ramo colores pastel rosa, blanco y verde", "precio" => 143, "cantidad" => 1],
    ["id" => 20, "imagen" => "./imagenes/ramoFlores1.jpeg", "nombre" => "Ramo colores vivos", "descripcion" => "Ramo colores fuertes verde, burdeos, rosa, amarillo ", "precio" => 100, "cantidad" => 1],
    ["id" => 21, "imagen" => "./imagenes/ramoFlores2.jpeg", "nombre" => "Ramo blanco y rosa", "descripcion" => "Ramo elegante blanco y diferentes tonos de rosa", "precio" => 150, "cantidad" => 1]
];


// Verifico si hay productos en el carrito
$carrito = $_SESSION["carrito"] ?? [];

// Calculo el total de la compra
$total = 0;
foreach ($carrito as $item) {
    $producto = $productos[$item["producto_id"]];
    $total += $producto["precio"];
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["finalizar_compra"])) {
        // Muestro el resumen de la compra
        $resumen = [];
        foreach ($carrito as $item) {
            $producto = $productos[$item["producto_id"]];
            $resumen[] = [
                "descripcion" => $producto["descripcion"],
                "precio" => $producto["precio"],
                "fecha" => $item["fecha_usuario"]
            ];
        }
        $_SESSION["carrito"] = []; //se vacia el carrito después de la compra

        // Redirigo a la pantalla de pago
        $_SESSION["resumen_compra"] = $resumen;
        $_SESSION["total_compra"] = $total;
        header("Location: pago.php");
        exit();
    } elseif (isset($_POST["vaciar_carrito"])) {
        $_SESSION["carrito"] = []; // Vaciar el carrito
    }

    
    header("Location: carrito.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrito de Compras</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container my-5">
        <h1>Carrito de Compras</h1>
        <?php if (empty($carrito)): ?>
            <p>No hay productos en el carrito.</p>
        <?php else: ?>
            <ul class="list-group">
                <?php foreach ($carrito as $item): ?>
                    <?php $producto = $productos[$item["producto_id"]]; ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <div>
                            <strong><?php echo htmlspecialchars($producto["descripcion"]); ?></strong><br>
                            Precio: <?php echo htmlspecialchars($producto["precio"]); ?> €<br>
                            Fecha seleccionada: <?php echo htmlspecialchars($item["fecha_usuario"]); ?>
                        </div>
                        <img src="<?php echo htmlspecialchars($producto["imagen"]); ?>" alt="Imagen del producto" style="width: 100px;">
                    </li>
                <?php endforeach; ?>
            </ul>

            <!-- Resumen del Total -->
            <div class="mt-3">
                <h4>Total de la compra: <?php echo htmlspecialchars($total); ?> €</h4>
            </div>

            <form method="POST" class="mt-3">
                <button type="submit" name="finalizar_compra" class="btn btn-success">Finalizar Compra</button>
                <button type="submit" name="vaciar_carrito" class="btn btn-danger">Vaciar Carrito</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>