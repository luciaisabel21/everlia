<?php

include_once $_SERVER['DOCUMENT_ROOT'] . "/DWES_P3_LUCIAI/model/Persona.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/DWES_P3_LUCIAI/model/Usuario.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/DWES_P3_LUCIAI/model/Invitado.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/DWES_P3_LUCIAI/model/ListaBoda.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/DWES_P3_LUCIAI/model/Regalo.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/DWES_P3_LUCIAI/model/Venta.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/DWES_P3_LUCIAI/model/Producto.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/DWES_P3_LUCIAI/model/Viaje.php";
include_once $_SERVER['DOCUMENT_ROOT'] . "/DWES_P3_LUCIAI/model/Carrito.php";

function conectar(){
    $server = "127.0.0.1";
    $user = "root";
    $password = "casavieja";
    $db = "everlia";

    $conexion = new mysqli($server, $user, $password, $db);

    if ($conexion->connect_error) {
        die("Error de conexión: " . $conexion->connect_error);
    }
    return $conexion;
}

function crearTablaPersona() {
    $c = conectar();

    // TABLA PERSONA
    $sql = "CREATE TABLE IF NOT EXISTS persona (
        id INT AUTO_INCREMENT PRIMARY KEY,  
        nombre VARCHAR(100) NOT NULL,
        email VARCHAR(115),
        password_hash VARCHAR(255) NOT NULL, 
        tipo ENUM('usuario', 'invitado') NOT NULL
        
    )";

    if (!$c->query($sql)) {
        die("Error al crear tabla persona: " . $c->error);
    }
}

    function crearTablaUsuario() {
        $c = conectar();

    // TABLA USUARIO
    $sql = "CREATE TABLE IF NOT EXISTS usuario (
        id INT AUTO_INCREMENT PRIMARY KEY,
        telefono VARCHAR(20),
        genero ENUM('Masculino', 'Femenino', 'Otro'),
        FOREIGN KEY (id) REFERENCES persona(id)
    )";
    if (!$c->query($sql)) {
        die("Error al crear tabla usuario: " . $c->error);
    }
}
function crearTablaInvitado() {
    $c = conectar();

    // TABLA INVITADO
    $sql = "CREATE TABLE IF NOT EXISTS invitado (
        id INT AUTO_INCREMENT PRIMARY KEY,
        relacion VARCHAR(50),
        FOREIGN KEY (id) REFERENCES persona(id)
    )";
    if (!$c->query($sql)) {
        die("Error al crear tabla invitado: " . $c->error);
    }

    }

    function crearTablaListaBoda() {
        $c = conectar();
    // TABLA LISTA BODA
    $sql = "CREATE TABLE IF NOT EXISTS lista_boda (
        id INT AUTO_INCREMENT PRIMARY KEY,
        usuario_id INT NOT NULL,
        nombre_lista VARCHAR(100),
        fecha_creacion DATETIME,
        FOREIGN KEY (usuario_id) REFERENCES usuario(id)
    )";
    if (!$c->query($sql)) {
        die("Error al crear tabla lista_boda: " . $c->error);
    }
    }
    function crearTablaRegalo() {
        $c = conectar();

    // TABLA REGALO
    $sql = "CREATE TABLE IF NOT EXISTS regalo (
        id INT AUTO_INCREMENT PRIMARY KEY,
        lista_boda_id INT NOT NULL,
        nombre VARCHAR(100),
        descripcion TEXT,
        precio DECIMAL(10, 2),
        url_producto VARCHAR(1024),
        comprado BOOLEAN DEFAULT FALSE,
        FOREIGN KEY (lista_boda_id) REFERENCES lista_boda(id)
    )";
    if (!$c->query($sql)) {
        die("Error al crear tabla regalo: " . $c->error);
    }

    }
    function crearTablaVenta() {
        $c = conectar();
    // TABLA VENTA
    $sql = "CREATE TABLE IF NOT EXISTS venta (
        id INT AUTO_INCREMENT PRIMARY KEY,
        precio DECIMAL(10, 2),
        descripcion TEXT
    )";
    if (!$c->query($sql)) {
        die("Error al crear tabla venta: " . $c->error);
    }
    }
    function crearTablaViaje() {
        $c = conectar();

    // TABLA VIAJE
    $sql = "CREATE TABLE IF NOT EXISTS viaje (
        id INT AUTO_INCREMENT PRIMARY KEY,
        destino VARCHAR(100),
        fecha_disponible DATETIME,
        FOREIGN KEY (id) REFERENCES venta(id)
    )";
    if (!$c->query($sql)) {
        die("Error al crear tabla viaje: " . $c->error);
    }
    }
    function crearTablaProducto() {
        $c = conectar();

    // TABLA PRODUCTO
    $sql = "CREATE TABLE IF NOT EXISTS producto (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nombre VARCHAR(100),
        cantidad INT,
        FOREIGN KEY (id) REFERENCES venta(id)
    )";
    if (!$c->query($sql)) {
        die("Error al crear tabla producto: " . $c->error);
    }
    }
    function crearTablaCarrito() {
        $c = conectar();

    // TABLA CARRITO
    $sql = "CREATE TABLE IF NOT EXISTS carrito (
        id INT AUTO_INCREMENT PRIMARY KEY,
        usuario_id INT NOT NULL,
        FOREIGN KEY (usuario_id) REFERENCES usuario(id)
    )";
    if (!$c->query($sql)) {
        die("Error al crear tabla carrito: " . $c->error);
    }
    }

/**
 * Summary of registrarUsuario
 * @param mixed $id
 * @param mixed $nombre
 * @param mixed $email
 * @param mixed $telefono
 * @param mixed $pass
 * @param mixed $genero
 * @return bool
 * funcion para registrar a un usuario segun su id nombre emial telef contraseña y genero
 */
function registrarUsuario($id, $nombre, $email, $telefono, $pass, $genero) {
    $conexion = conectar();

    // Hash de la contraseña
    $password_hash = password_hash($pass, PASSWORD_DEFAULT);

    // Insertar en la tabla persona
    $sqlPersona = "INSERT INTO persona (id, nombre, email, password_hash) VALUES (?, ?, ?, ?)";
    $stmtPersona = $conexion->prepare($sqlPersona);
    $stmtPersona->bind_param("isss", $id, $nombre, $email, $password_hash);
    $stmtPersona->execute();

    // Obtener el ID generado para persona
    $idPersona = $conexion->insert_id;

    // Insertar en la tabla usuario
    $sqlUsuario = "INSERT INTO usuario (id, telefono, genero) VALUES (?, ?, ?)";
    $stmtUsuario = $conexion->prepare($sqlUsuario);
    $stmtUsuario->bind_param("iss", $idPersona, $telefono, $genero);
    $stmtUsuario->execute();


    // Cerrar las declaraciones
    $stmtPersona->close();
    $stmtUsuario->close();

    $conexion->close();

    return true;
}
?>